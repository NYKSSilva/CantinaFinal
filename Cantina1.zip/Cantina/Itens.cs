﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Cantina
{
    public class Itens
    {
        public string Nome { get; set; }
        public double Valor { get; set; }


        //public Itens(string nome, double valor)
        //{ 
        //    this.nome = nome;
        //    this.valor = valor; 

        //}
        //public string Nome
        //{
        //    get { return nome; }
        //    set { nome = value; }

        //}
        //public double Valor
        //{
        //    get { return valor; }
        //    set { valor = value; }
        //}
       
    }
}
